package model1.replay;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReplyDTO {
	private String replyno;
	private String replycomment;
	private String id;
	private String regidate;
	private String num;
}
